package main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MyViewController {

    public javafx.scene.control.Button pathButton;
    public javafx.scene.control.Button postingpathButton;
    public javafx.scene.control.Button resetButton;
    public javafx.scene.control.Button showDictionaryButton;
    public javafx.scene.control.Button loadDictionaryButton;
    public javafx.scene.control.Button startButton;
    public CheckBox stemming;
    public javafx.scene.control.TextField pathCorpus;
    public javafx.scene.control.TextField pathPosting;


    public javafx.scene.control.TextField queryoption1;
    public javafx.scene.control.TextField queryoption2;
    public CheckBox semantic;
    public CheckBox searchIden;
    public javafx.scene.control.Button runButton;
    public javafx.scene.control.Button browseFile;


    public boolean stemmingflag;
    public Parser parser;
    public Indexer indexer;

    public MyViewController() {

        stemmingflag = false;

    }


    public HashSet<String> createStopWordsTable(String stopWordsFilePath){

        HashSet<String> stopWordsTable = new HashSet<>();

        String word;

        try {

            BufferedReader bufferedReader = new BufferedReader(new FileReader(stopWordsFilePath));

            while ((word = bufferedReader.readLine()) != null) {

                stopWordsTable.add(word);
            }

            bufferedReader.close();
        }

        catch (IOException e){

            e.printStackTrace();
        }

        return stopWordsTable;
    }


    ///////checkbox

    public void browseCorpus(ActionEvent actionEvent) {

        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDict = directoryChooser.showDialog(null);
        if (selectedDict != null) {
            pathCorpus.setText(selectedDict.getAbsolutePath());
        }
        // String pathOfCourpus = pathCorpus.getText();
        //Parser p = new Parser(pathOfCourpus+"\\corpus\\stop_words.txt", new List[2]);
        // setParser(p);

    }

    public void browsePosting(ActionEvent actionEvent) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDict = directoryChooser.showDialog(null);
        if (selectedDict != null) {
            pathPosting.setText(selectedDict.getAbsolutePath());
        }
    }


    public void startIndexing(ActionEvent actionEvent) {
        if (pathCorpus.getText().length() == 0 || pathPosting.getText().length() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(" null checkbox "); //edit
            alert.show();
        } else {
            /// start indexing!
            // String pathOfCourpus = path1.getText();

            ReadFile readfile = new ReadFile(pathCorpus.getText(), pathPosting.getText(), pathCorpus.getText()+"\\corpus\\stop_words.txt");
            this.parser = readfile.getParser();
            parser.setStemming(stemmingflag);

            this.indexer = parser.getIndexer();
            long startTime = System.nanoTime();
            readfile.Read();
            long time = System.nanoTime() - startTime;

            //setParser(p);
            //Indexer indexer = new Indexer(parser);
            //indexer.IndexFiles();
            // indexer.WriteTheDictionaryToFile();
            //String pathOfPostingFiles = path2.getText();//// what to do with this


            /// need to do this things
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            int numberOfIndexedDocs = readfile.getDocId();///// need to do this function that count the docs that indexed
            int numberOfTerms = indexer.getDictionarySize();

            /*
//
//

             */

           ;////// need to put timers at the end and count the total time
            String message = "";
            message = message + "number of docs that indexed:" + numberOfIndexedDocs + "\n";
            message = message + " number of terms:" + numberOfTerms + "\n";
            message = message + " the total time of run time:" + time;
            alert.setContentText(message); //edit
            alert.show();
        }
        //check if the text are directories


    }

    public void useStemming(ActionEvent actionEvent) {
        if (stemming.isSelected()) {
            //parser.setStemming(true);
            stemmingflag = true;
        } else {
            // parser.setStemming(false);
            stemmingflag = false;
        }

    }



    public void loadDictionary(ActionEvent actionEvent) { ///// work
        TreeMap<String, Pair<Integer, String>> dictionaeytoLoad;


        dictionaeytoLoad = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        try {
            FileReader fr = new FileReader(pathPosting.getText() + "\\Dictionary.txt");
            BufferedReader bufferedReader = new BufferedReader(fr);
            String inputLine;
            while ((inputLine = bufferedReader.readLine()) != null) {

                String term = inputLine.substring(6, inputLine.indexOf(" Term Frequency from all corpus:"));
                int index = inputLine.indexOf("corpus:") + 8;
                String frequency = inputLine.substring(index);
                int frequencynum = Integer.parseInt(frequency);
                if (stemmingflag == false) {

                    if (term.charAt(0) >= 65 && term.charAt(0) <= 90) {

                        dictionaeytoLoad.put(term, new Pair(frequencynum, "posting." + term.toUpperCase().charAt(0) + ".txt"));
                    } else { /// number
                        dictionaeytoLoad.put(term, new Pair(frequencynum, "posting.numbers.txt"));
                    }
                } else { /// stemming is true
                    if (term.charAt(0) >= 65 && term.charAt(0) <= 90) {
                        dictionaeytoLoad.put(term, new Pair(frequencynum, "postingStemming." + term.toUpperCase().charAt(0) + ".txt"));

                    } else {
                        dictionaeytoLoad.put(term, new Pair(frequencynum, "postingStemming.numbers.txt"));

                    }
                }
            }
            bufferedReader.close();
            fr.close();
        } catch (Exception e) {
        }

        //ReadFile readfile = new ReadFile(pathCorpus.getText(), pathPosting.getText(), pathCorpus.getText()+"\\corpus\\stop_words.txt");
       // this.parser = readfile.getParser();
       // parser.setStemming(stemmingflag);

        this.indexer = new Indexer(pathPosting.getText(),stemmingflag);
        indexer.setDictionary(dictionaeytoLoad);
        System.out.println(indexer.getDictionarySize());


    }


    public void showDictionary(ActionEvent actionEvent) {///
        ObservableList<String> data = FXCollections.observableArrayList();

        ListView<String> listView = new ListView<String>(data);
        TreeMap<String, Pair<Integer, String>> dictionary;
        dictionary = indexer.getDictionary();
        dictionary.forEach((key, value) -> {
            data.add(key + " " + value.getKey());
            listView.setItems(data);

        });
        VBox vbox = new VBox(listView);


        Scene scene = new Scene(vbox);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();





/*
        TableView tableView = new TableView();

        TableColumn<String, String> column1 = new TableColumn<>("Term");
        column1.setCellValueFactory(new PropertyValueFactory<>("Term"));


        TableColumn<String, Integer> column2 = new TableColumn<>("Frequency");
        column2.setCellValueFactory(new PropertyValueFactory<>("Frequency"));


        tableView.getColumns().add(column1);
        tableView.getColumns().add(column2);

        TreeMap<String,Pair<Integer,String>> dictionary;
        dictionary=indexer.getDictionary();

        for( HashMap.Entry<String,Pair<Integer,String>> map: dictionary.entrySet()) {
           tableView.getItems().add(map.getKey());








            //tableView.getItems().add(new Pair(map.getKey(),map.getValue().getKey()));
        }
        tableView.sort();
        VBox vbox = new VBox(tableView);


        Scene scene = new Scene(vbox);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();


/*
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            FileReader fr = new FileReader(pathPosting.getText() + "\\Dictionary.txt");
            BufferedReader bufferedReader = new BufferedReader(fr);
            String inputLine;
            String str = "";
            while ((inputLine = bufferedReader.readLine()) != null) {
                str = str + inputLine + "\n";
                //  alert.setContentText(inputLine);
            }
            alert.setContentText(str);
            fr.close();
            bufferedReader.close();
            alert.show();
        } catch (Exception e) {
        }


 */


    }

    public void ResetDIctionary(ActionEvent actionEvent) {


        // delete the A-Z FILES AND THE POSTING FILES
        for (char c = 'A'; c <= 'Z'; c++) {
            //File file = new File(pathPosting.getText() + "//" + c + ".txt");
            //file.delete();
            if(stemmingflag==false) {
                File filesPosting = new File((pathPosting.getText() + "//posting." + c + ".txt"));
                if (!filesPosting.exists()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("posting files doesnt exist");
                    alert.show();
                    break;
                } else {
                    filesPosting.delete();
                }
            }
            else {
                File fileWithStemmingPosting = new File((pathPosting.getText() + "//postingStemming." + c + ".txt"));

                if (!fileWithStemmingPosting.exists()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("posting files doesnt exist");
                    alert.show();
                    break;
                } else {
                    fileWithStemmingPosting.delete();
                }

            }
        }
        /// DELETE THE NUMBERS FILE AND POSTING FILE
        //File file = new File(path2.getText() + "//numbers.txt");
        //file.delete();
        if(stemmingflag==false) {
            File filePostingNum = new File(pathPosting.getText() + "//posting.numbers.txt");
            if (!filePostingNum.exists()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("posting files doesnt exist");
  //              alert.show();

            } else {
                filePostingNum.delete();
            }

        }
        else {
            File fileWithStemmingPosting = new File((pathPosting.getText() + "//postingStemming.numbers.txt"));

            if (!fileWithStemmingPosting.exists()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("posting files doesnt exist");
//                alert.show();

            } else {
                fileWithStemmingPosting.delete();
            }
        }
        //delete the doctionary files
     //   File dictionary = new File(pathPosting.getText() + "//Dictionary.txt");
       // dictionary.delete();
        stemmingflag = false;


        // reset the memory somehow


    }


    ///part B

    public void runQuery(ActionEvent actionEvent){
        Parser parser = new Parser(new DateForParser(),queryoption2.getText(),createStopWordsTable(queryoption2.getText()));
        this.parser = parser;

        Searcher searcher = new Searcher(parser,queryoption2.getText().substring(0,queryoption2.getText().indexOf("queries.txt")-1));
        HashMap <String,Double> results = new HashMap<>();

        if(queryoption1.getText().length()!=0 && queryoption2.getText().length()==0) {
            results= searcher.runOneQuery(queryoption1.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            /////// need to show the number of relavant docs. IMPLEMENT
            String numberOfRelevantDocs="30";////// to change!
            alert.setContentText(numberOfRelevantDocs);
            alert.show();



            ObservableList<String> data = FXCollections.observableArrayList();

            ListView<String> listView = new ListView<String>(data);

            results.forEach((key, value) -> {
                data.add(key);
                listView.setItems(data);

            });
            VBox vbox = new VBox(listView);


            Scene scene = new Scene(vbox);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();

        }
        else if (queryoption2.getText().length()!=0 && queryoption1.getText().length()==0)
        {
            searcher.runMoreThanOneQuery(queryoption2.getText());


        }




    }
    public void browseQueryFile(ActionEvent actionEvent){
        FileChooser fileChooser = new FileChooser();

        File selectedfile = fileChooser.showOpenDialog(null);
        if (selectedfile != null) {
            queryoption2.setText(selectedfile.getAbsolutePath());
        }

    }

    public void searchIdentities(ActionEvent actionEvent){

    }
    public void semanticTreatment(ActionEvent actionEvent){

    }




}

