package main;

import javafx.util.Pair;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.stream.Collectors;

public class Searcher {
    private Ranker ranker; //maybe ranker have searcher
    private Parser parser;
    private boolean identitiesRecognize;
    private ArrayList<String> listOfDocs;
    private HashMap<String, Pair<String,Integer>> identities;
    private String pathOfQueriesFile;

   public Searcher(){
      /////to implement

   }





    public HashMap<String,Double> runOneQuery (String query){
        HashMap<String,Double>  result = new HashMap<>();
        HashMap<String,Integer> queryAfterParse = parser.parseQuery(query);
       // result= ranker.getRankDocs (queryAfterParse);//// need to be function in ranker

        try{

                BufferedWriter writer = new BufferedWriter(new FileWriter("resultFrom1Query.txt", true));//// need to add the path of the folder

            for(Map.Entry<String,Double> id: result.entrySet()){
                writer.write("111 0 "+id.getKey()+" 1 42.38 iAm"); // the other parameters are for trec eval
            }
        }
        catch (Exception e){}
        return result;

    }


    public void runMoreThanOneQuery ( String path){
        File file = new File(path);
        String [] queries = new String[15];
        String [] queriesID = new String[15];
     try{
        BufferedReader br = new BufferedReader(new FileReader(file));
        int countQuery=0;

        String line = br.readLine();
        int indexQuery=0;
        int indexQueryNum=0;


        while(countQuery!=15) {
            if(line !=null) {
                if(line.contains("<num>")){
                    queries[indexQueryNum] = line.substring(14);
                    indexQueryNum++;

                }
                if (line.contains("<title>")) {
                    queries[indexQuery] = line.substring(8);
                    indexQuery++;
                }
                if (line.contains("</top>")) {
                   countQuery++;
                }
            }
            line = br.readLine();
        }
        br.close();
    }
    catch (Exception e){}


        try {
            String folderPath = path.substring(0, path.indexOf("queries.txt"));
            BufferedWriter writer = new BufferedWriter(new FileWriter(folderPath+"result.txt", true));

            for(int j=0;j<queries.length;j++){
               HashMap<String,Double> queryResult=new HashMap<>();

                HashMap<String,Integer> queryAfterParse = parser.parseQuery(queries[j]);
                // queryResult= ranker.getRankDocs (queryAfterParse);//// need to be function in ranker

                for(Map.Entry<String,Double> id: queryResult.entrySet()){
                    writer.write(queriesID[j]+" 0 "+id.getKey()+" 1 42.38 iAm"); // the other parameters are for trec eval
                }
            }
            writer.close();
        }
        catch (Exception e){}

         //// need to think how to save the outputs - trec eval format
     }







        public double getGradeForIdentities(){

        return 2.0;
    }




}
