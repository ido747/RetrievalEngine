package main;

public class Ranker {
}
