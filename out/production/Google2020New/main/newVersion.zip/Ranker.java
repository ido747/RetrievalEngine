package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class Ranker {

    private String postingFilesPath;
    private HashMap<String, Term> dictionary;
    private double avgDocLength;
    private double NumOfDocsInCorpus;
    private double k1;
    private double b;
    private int numOfReleventDocs;
    private HashMap<String, String> docInfo;

    public Ranker(String postingFilesPath) {

        //read the value of avgDocLength and NumOfDocsInCorpus from "corpusInfo.txt"

        //read dictionary and docInfo
        this.postingFilesPath = postingFilesPath;
        loadDictionary();
        loadDocInfo();
        //this.dictionary = dictionary;
        this.NumOfDocsInCorpus = NumOfDocsInCorpus;
        this.avgDocLength = avgDocLength;
        k1 = 1.2; //[1.2,2.0]
        b = 0.75;
    }

    public HashMap<String, Double> rank(HashMap<String, Integer> queriesTerms) {

        LinkedHashMap<String, Double> retrievalDocs = new LinkedHashMap<>();

        String docNo;
        double termFrequency; //from term posting files
        double docLength; //from docInformation.txt
        double numberOfDocWhichTermIsShown; //from dictionary
        double IDF;
        double formulaResult;
        double queryFrequency;

        boolean ifFound  = false;
        String[] arrayForPosting;
        String pointer;


        for(Map.Entry<String, Integer> entry : queriesTerms.entrySet()) {

            String term = entry.getKey();
            queryFrequency = entry.getValue();
            numberOfDocWhichTermIsShown = dictionary.get(term).getNumOfTotalDocs();
            pointer = dictionary.get(term).getPostingFilrPointer();

            try {

                FileReader fileReader1 = new FileReader(postingFilesPath + "/" + pointer);
                BufferedReader termPosting = new BufferedReader(fileReader1);
                String line;

                while ((line = termPosting.readLine()) != null) {

                    arrayForPosting = line.split(",");

                    if (arrayForPosting[0].equals(term)) { //found the line that term is located in posting file

                        ifFound = true;

                        while (line != null && arrayForPosting[0].equals(term)) {

                            docNo = arrayForPosting[1];
                            termFrequency = Double.parseDouble(arrayForPosting[2]);

                            //docInfo.put(docNo, max_tf + "," + uniqueWordsSize + "," + docLength);
                            docLength = Integer.parseInt(docInfo.get(docNo).split(",")[2]);

                            //IDF = Math.log(NumOfDocsInCorpus - documentFrequency + 0.5) / (documentFrequency + 0.5);
                            IDF = Math.log((NumOfDocsInCorpus + 1) / (numberOfDocWhichTermIsShown));

                            formulaResult = queryFrequency * IDF * (((termFrequency) * (k1 + 1))
                                    / ((termFrequency) + k1 * (1 - b + b * (docLength / avgDocLength))));

                            if (retrievalDocs.containsKey(docNo)) {

                                retrievalDocs.put(docNo, retrievalDocs.get(docNo) + formulaResult);
                            } else {

                                retrievalDocs.put(docNo, formulaResult);
                            }

                            line = termPosting.readLine();
                            arrayForPosting = line.split(",");
                        }

                    } else if(ifFound){ //check if pass the line of the term in posting file!

                        ifFound = false;
                        break;
                    }

                }

                orderByValue(retrievalDocs, new Comparator<Double>() {
                    @Override
                    public int compare(Double o1, Double o2) {
                        return o1.compareTo(o2);
                    }
                });

                FileReader fileReader2 = new FileReader(postingFilesPath + "/" + pointer);
                BufferedReader docInformation = new BufferedReader(fileReader1);


                fileReader1.close();
                termPosting.close();
            } catch (Exception e) {

            }
        }


        return retrievalDocs;
    }

    static <K, V> void orderByValue(
            LinkedHashMap<K, V> m, Comparator<? super V> c) {
        List<Map.Entry<K, V>> entries = new ArrayList<>(m.entrySet());
        m.clear();
        entries.stream()
                .sorted(Comparator.comparing(Map.Entry::getValue, c))
                .forEachOrdered(e -> m.put(e.getKey(), e.getValue()));
    }

    //docInfo.put(docNo, max_tf + "," + uniqueWordsSize + "," + docLength);
    // writer.append(entry.getKey() + "," + entry.getValue() + "\n");
    public void loadDocInfo() {

        docInfo = new HashMap<>();

        try {

            FileReader fr = new FileReader(postingFilesPath + "/docInformation.txt");
            BufferedReader bufferedReader = new BufferedReader(fr);
            String inputLine;

            //System.out.println(s.substring(s.indexOf(",") + 1));

            while ((inputLine = bufferedReader.readLine()) != null) {

                String docNo = inputLine.substring(0, inputLine.indexOf(","));
                String info = inputLine.substring(inputLine.indexOf(",") + 1);
                docInfo.put(docNo, info);
            }
            bufferedReader.close();
            fr.close();
        }

        catch (Exception e) {

        }
    }

    public void loadDictionary() {

        dictionary = new HashMap<>();

        try {

            FileReader fr = new FileReader(postingFilesPath + "/Dictionary.txt");
            BufferedReader bufferedReader = new BufferedReader(fr);
            String inputLine;

            while ((inputLine = bufferedReader.readLine()) != null) {

                String[] infoPiece = inputLine.split(",");
                Term term = new Term(infoPiece[0], Integer.parseInt(infoPiece[3]), infoPiece[1], Integer.parseInt(infoPiece[2]));
                dictionary.put(term.getName(), term);
                //need to consider option of stemming
            }
            bufferedReader.close();
            fr.close();
        }

        catch (Exception e) {

        }
    }
}
