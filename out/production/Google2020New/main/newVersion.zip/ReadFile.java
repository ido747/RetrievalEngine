package main;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.concurrent.*;

public class ReadFile {

    private String corpusPath;
    private int startFile;
    private int endFile;
    private ExecutorService executorService;
    private Parser parser;
    private int docId;
    private String docNo;
    private String filePath;
    //HashSet<String> hasSerOfDocs;
    //LinkedList<String> linkedList;


    public ReadFile(String corpusPath, String postingPath, String stopWordsPath) {

        //this.parser = parser;
        this.filePath = filePath;
        this.corpusPath = corpusPath;
        this.startFile = startFile;
        this.endFile = endFile;
        //this.docId = 0;
        this.executorService = Executors.newFixedThreadPool(4);
        parser = new Parser(new DateForParser(), postingPath, createStopWordsTable(stopWordsPath));

    }

    public Parser getParser() {
        return parser;
    }

    public int getDocId() {
        return docId;
    }
    public String getDocNo(){return docNo;}

    public void Read() {

        //LinkedList<String> linkedList = new LinkedList<>();
        int sum=0;
        File fatherDir = new File(corpusPath + "/corpus");
        File[] files = fatherDir.listFiles();
       // int count = 0;
        //int x = 0;
        //int serialnum = 1;
        for (int i = 0; i < files.length; i++) {//size of files number/4
            System.out.println(i);
            //x++;
            if (!(files[i].isFile())) {
                String newPath = corpusPath + "/corpus/"  + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data = br.lines().collect(Collectors.joining());// it work not sure why
                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    //int number = arrToSplit

                    for(int J = 0; J < arrToSplit.length; J++){


                        int temp = J;
                        int id = docId;
                        ////ido add
                        int indexStartdocNo = arrToSplit[J].indexOf("<DOCNO>");
                        int indexLastdocNo = arrToSplit[J].indexOf("</DOCNO>");
                        docNo= arrToSplit[J].substring(indexStartdocNo+7,indexLastdocNo);
                        docNo = docNo.replaceAll(" ","");
                        ////

                        if(arrToSplit[J].contains("<TEXT>")){

                            int indexStart = arrToSplit[J].indexOf("<TEXT>");
                            int indexLast = arrToSplit[J].indexOf("</TEXT>");
                            arrToSplit[J] = arrToSplit[J].substring(indexStart + 6, indexLast);
                            System.out.println("**************** finish Reading doc: " + docId+ " *******************");
                            parser.parse(arrToSplit[temp], docId,docNo);
                            //this.executorService.submit(() -> this.parser.parse(arrToSplit[temp], id));
//                            try {
//                                Thread.sleep(20);
//                            }
//                            catch (Exception e){
//
//                            }

//                            this.parser.parse(arrToSplit[J], docId);
                            docId++;
                        }


                        //else don't parse
                    }


                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                //count++;
                //System.out.println(count);

            }
        }

    }

    //creating hash set which contains all the stop words
    public HashSet<String> createStopWordsTable(String stopWordsFilePath){

        HashSet<String> stopWordsTable = new HashSet<>();

        String word;

        try {

            BufferedReader bufferedReader = new BufferedReader(new FileReader(stopWordsFilePath));

            while ((word = bufferedReader.readLine()) != null) {

                stopWordsTable.add(word);
            }

            bufferedReader.close();
        }

        catch (IOException e){

            e.printStackTrace();
        }

        return stopWordsTable;
    }
}



        /*


        for (int i = 100; i <200 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why
                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject2.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 200; i <300 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why
                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }

        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject3.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 300; i <400 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject4.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 400; i <500 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject5.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 500; i <600 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject6.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 600; i <700 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject7.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 700; i <800 ; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject8.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 800; i <900; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject9.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();

        for (int i = 900; i <1000; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject10.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1000; i <1100; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject11.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1100; i <1200; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why


                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));

                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }

        }

        try (FileOutputStream fos = new FileOutputStream("serializedObject12.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1200; i <1300; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject13.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1300; i <1400; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject14.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1400; i <1500; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject15.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1500; i <1600; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject16.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1600; i <1700; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why

                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject17.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();
        for (int i = 1700; i <files.length; i++) {//size of files number/4
            if (!(files[i].isFile())) {
                String newPath = path + "\\" + files[i].getName();
                File dir2 = new File(newPath);
                File[] contentFiles = dir2.listFiles();
                try (FileReader reader = new FileReader(contentFiles[0]);
                     BufferedReader br = new BufferedReader(reader)) {
                    String data =br.lines().collect(Collectors.joining());// it work not sure why


                    //System.out.println(data);

                    String[] arrToSplit = data.split("</DOC>");
                    hasSerOfDocs.addAll(Arrays.asList(arrToSplit));
                    //System.out.println(al.size());

                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }
                count++;
                //System.out.println(count);



            }
        }
        try (FileOutputStream fos = new FileOutputStream("serializedObject18.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(hasSerOfDocs);
            oos.close();
            fos.close();
        }
        catch (Exception e){

        }
        hasSerOfDocs.clear();

    }
}

         */











